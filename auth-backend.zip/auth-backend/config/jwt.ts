export const JWT_SECRET = 'super_secret_key';
export const JWT_EXPIRES_IN = '1h';