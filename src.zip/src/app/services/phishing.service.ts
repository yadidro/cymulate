import {Injectable} from "@angular/core";
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Observable} from "rxjs";
import {ResponseFromService} from "../models/response";
import {phishingRequest} from "../models/phishingRequest";

@Injectable({ providedIn: 'root' })
export class PhishingService {
  private apiUrl = 'http://localhost:5252/phishing';

  constructor(private http: HttpClient) {}



  getAllAttempts(): Observable<ResponseFromService> {
    const token = localStorage.getItem('token');
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });

    return this.http.get<ResponseFromService>(`${this.apiUrl}`, { headers });
  }

  sendPhishingEmail(request: phishingRequest): Observable<ResponseFromService> {
    const token = localStorage.getItem('token');
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`,
    });
    return this.http.post<ResponseFromService>(`${this.apiUrl}/send`, request, { headers });
  }

}
