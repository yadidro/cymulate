import { Component } from '@angular/core';
import { PhishingService } from 'src/app/services/phishing.service';
import {phishingRequest} from "../../models/phishingRequest";

@Component({
  selector: 'app-send-phishing',
  templateUrl: './send-phishing.component.html'
})
export class SendPhishingComponent {
  name = '';
  email = '';
  message = '';

  constructor(private phishingService: PhishingService) {}

  sendEmail() {
    const request: phishingRequest = {
      name: this.name,
      email: this.email
    };

    this.phishingService.sendPhishingEmail(request).subscribe({
      next: (res) => this.message = res.response,
      error: (err) => this.message = 'Failed to send email: ' + err.error
    });
  }
}
