import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SendPhishingComponent } from './send-phishing.component';

describe('SendPhishingComponent', () => {
  let component: SendPhishingComponent;
  let fixture: ComponentFixture<SendPhishingComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SendPhishingComponent]
    });
    fixture = TestBed.createComponent(SendPhishingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
