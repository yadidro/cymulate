import { Component, OnInit } from '@angular/core';
import { PhishingService } from 'src/app/services/phishing.service';
import {ResponseFromService} from "../../models/response";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
})
export class DashboardComponent implements OnInit {
  phishingAttempts: any[] = [];

  constructor(private phishingService: PhishingService) {}

  ngOnInit(): void {
    this.phishingService.getAllAttempts().subscribe({
      next: (data : ResponseFromService) => (this.phishingAttempts = JSON.parse(data.response)),
      error: (err) => console.error('Error loading data:', err),
    });
  }
}
