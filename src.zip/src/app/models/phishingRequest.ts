export interface phishingRequest {
  name: string;
  email: string;
}
