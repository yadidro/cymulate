export interface ResponseFromService {
  response: string;
}
